﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Imaging;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace JuegoDeLaVida
{
    class PintaMapa
    {
        public enum ColorChannel : int { RED = 2, GREEN = 1, BLUE = 0, ALPHA = 3 }

        private int RowSizeBytes;
        private byte[] PixBytes;
        private BitmapData Mapeo;

        public void LockBitmap(Bitmap bm, bool ReadOnly = false)
        {
            // Bloquea los datos de mapa de bits.
            Rectangle bounds = new Rectangle(0, 0, bm.Width, bm.Height);
            Mapeo = bm.LockBits(bounds, ReadOnly ? ImageLockMode.ReadOnly : ImageLockMode.ReadWrite, PixelFormat.Format32bppArgb);
            RowSizeBytes = Mapeo.Stride;

            // Asignar espacio para los datos.
            int total_size = Mapeo.Stride * Mapeo.Height;
            PixBytes = new byte[total_size + 1];

            // Copia los datos dentro del g_PixBytes.
            Marshal.Copy(Mapeo.Scan0, PixBytes, 0, total_size);
        }

        public void UnlockBitmap(Bitmap bm)
        {

            int total_size = Mapeo.Stride * Mapeo.Height;
            Marshal.Copy(PixBytes, 0, Mapeo.Scan0, total_size);


            bm.UnlockBits(Mapeo);


            PixBytes = null;
            Mapeo = null;
        }

        public Color GetPixel(int x, int y)
        {
            return Color.FromArgb(PixBytes[GetArrayPos(x, y, ColorChannel.ALPHA)],
                                  PixBytes[GetArrayPos(x, y, ColorChannel.RED)],
                                  PixBytes[GetArrayPos(x, y, ColorChannel.GREEN)],
                                  PixBytes[GetArrayPos(x, y, ColorChannel.BLUE)]);
        }

        public void SetPixel(int x, int y, Color c)
        {
            PixBytes[GetArrayPos(x, y, ColorChannel.RED)] = c.R;
            PixBytes[GetArrayPos(x, y, ColorChannel.GREEN)] = c.G;
            PixBytes[GetArrayPos(x, y, ColorChannel.BLUE)] = c.B;
            PixBytes[GetArrayPos(x, y, ColorChannel.ALPHA)] = c.A;
        }

        public int GetArrayPos(int x, int y, ColorChannel c)
        {
            return Convert.ToInt32((RowSizeBytes * y + x * 4) + c);
        }
    }
}
