﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JuegoDeLaVida
{
    public static class Conexiones
    {
        public static void Add(this IList<Point> a, int X, int Y)
        {
            a.Add(new Point(X, Y));
        }
    }
}
