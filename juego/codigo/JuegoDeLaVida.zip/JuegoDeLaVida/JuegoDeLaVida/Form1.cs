﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;
using System.Drawing;


namespace JuegoDeLaVida
{
    public partial class Form1 : Form
    {
        private JuegoDeLaVida jv;
        private Colonia graf;
        private int GridSize = 400;
        private double OcupacionInicial = .5;
        private int EdadMaxima = 200;
        private string Algoritmo = "23/3";
        private Thread workerThread;

        public Form1()
        {
            InitializeComponent();
            this.Shown += Form1_Shown;
            this.FormClosing += Form1_FormClosing;
            Inicializar();
        }
    private void Inicializar()
    {
        this.Controls.Remove(graf);
        jv = new JuegoDeLaVida(GridSize, GridSize, Algoritmo, EdadMaxima, this.OcupacionInicial);
        jv.Actualizando += jv_FireUpdate;
        graf = new Colonia(GridSize, GridSize);
        graf.Dock = DockStyle.Fill;
        this.Controls.Add(graf);
    }

    private void Comenzar()
    {
        AbortWorker();
        workerThread = new Thread(jv.Jugar);
        workerThread.Priority = ThreadPriority.AboveNormal;
        workerThread.Start();
    }

    private void AbortWorker()
    {
        if (workerThread != null && workerThread.IsAlive)
        {
            workerThread.Abort();
            workerThread.Join();
        }
    }


    private void Form1_FormClosing(object sender, System.Windows.Forms.FormClosingEventArgs e)
    {
        AbortWorker();
    }

    private void Form1_Shown(object sender, System.EventArgs e)
    {
        Comenzar();
    }

    private void jv_FireUpdate(object sender, ActualizaEventos e)
    {
        foreach (Point nace in e.Nacidos)
        {
            graf.PlotBmp(nace.X, nace.Y, 1);
        }
        foreach (Point muere in e.Muertos)
        {
            graf.PlotBmp(muere.X, muere.Y, 0);
        }
        graf.Invalidate();
    }
}
}
