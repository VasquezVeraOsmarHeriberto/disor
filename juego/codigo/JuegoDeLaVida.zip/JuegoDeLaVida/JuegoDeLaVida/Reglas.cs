﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JuegoDeLaVida
{
    public struct Reglas
    {
        private List<byte> SigueVivaSi;
        private List<byte> NaceSi;

        public Reglas(string Simbolo)
        {
            string[] ns = Simbolo.Split('/');
            if (ns.Length != 2)
            {
                throw new ArgumentException("Formato erróneo");
            }
            List<byte> Conway_VivaSi = new List<byte>();
            foreach (char c in ns[0])
            {
                Conway_VivaSi.Add(Convert.ToByte(Char.GetNumericValue(c)));
            }
            List<byte> Conway_NaceSi = new List<byte>();
            foreach (char c in ns[1])
            {
                Conway_NaceSi.Add(Convert.ToByte(Char.GetNumericValue(c)));
            }
            SigueVivaSi = Conway_VivaSi;
            NaceSi = Conway_NaceSi;
        }

        public Reglas(List<byte> VivaSi, List<byte> NaceSi)
        {
            this.SigueVivaSi = VivaSi;
            this.NaceSi = NaceSi;
        }

        public string Simbolo
        {
            get
            {
                string s = "";
                foreach (byte i in SigueVivaSi)
                {
                    s += i.ToString();
                }
                s += "/";
                foreach (byte i in NaceSi)
                {
                    s += i.ToString();
                }
                return s;
            }
        }

        public bool EvualuarProximoEstado(byte iEstadoActual, byte iVecinosVivos, byte iVecinosFertiles)
        {
            //Está muerta, ver si puede nacer
            if (iEstadoActual == 0 && NaceSi.Contains(iVecinosFertiles))
            {
                return true;
            }
            //Está viva, ver si puede seguir viva
            if (iEstadoActual > 0 && SigueVivaSi.Contains(iVecinosVivos))
            {
                return true;
            }
            return false;
        }

    }
}
