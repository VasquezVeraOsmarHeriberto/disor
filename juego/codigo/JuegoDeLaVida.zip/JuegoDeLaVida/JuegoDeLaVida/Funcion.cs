﻿using System;
using System.Threading;
using System.Windows.Forms;

namespace JuegoDeLaVida
{
    public static class Funcion
    {
        private static Mutex mutex;

        [STAThread]
        public static void Mainsito()
        {
            if (PrevInstance())
            {
                Application.Exit();
                return;
            }
            Application.Run(new Form1());
        }

        /// <summary>
        /// Determina si existe alguna instancia previa del programa corriendo
        /// </summary>
        public static bool PrevInstance()
        {
            //Obtengo el nombre del ensamblado donde se encuentra ésta función
            string NombreAssembly = System.Reflection.Assembly.GetExecutingAssembly().GetName().Name;
            //Nombre del mutex según Tipo (visibilidad)
            string mutexName = "Global\\" + NombreAssembly;
            bool newMutexCreated = false;
            try
            {
                //Abro/Creo mutex con nombre único
                mutex = new Mutex(false, mutexName, out newMutexCreated);
                if (newMutexCreated)
                {
                    //Se creó el mutex, NO existe instancia previa
                    return false;
                }
                else
                {
                    //El mutex ya existía, Libero el mutex 
                    mutex.Close();
                    return true;
                }
            }
            catch (Exception)
            {
                return false;
            }
        }
    }
}
