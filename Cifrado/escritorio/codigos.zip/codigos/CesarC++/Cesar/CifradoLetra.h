#include "ContenidoAlfabeto.h"

class CifradoLetra:public ContenidoAlfabeto
{
public:
	char letraCifrada(char letra, int desplazamiento, int suma, int posicion);
};

