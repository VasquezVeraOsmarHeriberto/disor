#include <iostream>

using namespace std;

class Alfabeto
{
public:
	string alfabeto_spanish();
};

