#include <iostream>
#include "Alfabeto.h"
using namespace std;

class ContenidoAlfabeto:public Alfabeto
{
public:
	int posicionEn_elAlfabeto(char letra);
};

