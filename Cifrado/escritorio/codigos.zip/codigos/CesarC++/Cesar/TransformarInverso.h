#include <iostream>

using namespace std;

class TransformarInverso
{
public:
	string inverso(string texto, string texto_inverso);
};

