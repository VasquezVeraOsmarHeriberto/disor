import m from "mithril";

let Alfabeto {
    alfabeto: "aábcdeéfghiíklmnñoópqrstuvwxyz".split('')
}