class Alfabeto:

    def alfabetoSpanish(self):
        alfabeto = ['a','á','b','c','d','e','é','f','g','h','i','í','j','k','l','m','n','ñ','o','ó','p','q','r','s','r','t','u','ú','v','w','x','y','z']
        return alfabeto