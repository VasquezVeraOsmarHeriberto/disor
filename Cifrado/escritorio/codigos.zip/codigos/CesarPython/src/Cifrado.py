from src.Alfabeto import Alfabeto
from src.ContenidoAlfabeto import ContenidoAlfabeto

class CifradoCesar:
    alfabeto=Alfabeto()
    contenidoAlfabeto=ContenidoAlfabeto()

    def cifraLetra(self,desplazamiento,posicion):
        suma = desplazamiento + posicion
        print(suma)
        if suma > len(self.alfabeto.alfabetoSpanish()):
            return self.alfabeto.alfabetoSpanish()[suma - len(self.alfabeto.alfabetoSpanish())]
        elif suma < 0:
            return self.alfabeto.alfabetoSpanish()[len(self.alfabeto.alfabetoSpanish()) + suma]
        else:
            return self.alfabeto.alfabetoSpanish()[suma]

    def cifraMensajePlano(self, textoPlano, desplazamiento, textoCifrado):
        for letra in textoPlano:

            if self.contenidoAlfabeto.posicionEnElAlfabeto(letra) != (-1):
                textoCifrado = textoCifrado + str(self.cifraLetra(desplazamiento, self.contenidoAlfabeto.posicionEnElAlfabeto(letra)))
            else:
                textoCifrado = textoCifrado + str(letra)

        return textoCifrado
