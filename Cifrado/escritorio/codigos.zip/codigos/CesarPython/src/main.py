from src.Cifrado import CifradoCesar

cifrado=CifradoCesar()

print(cifrado.cifraMensajePlano("hola",3,""))