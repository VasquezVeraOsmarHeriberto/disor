from src.Alfabeto import Alfabeto

class ContenidoAlfabeto:
    alfabeto=Alfabeto()

    def posicionEnElAlfabeto(self,letra):
        print(letra)
        i=0
        for letrasAlfabeto in self.alfabeto.alfabetoSpanish():
            if letra == letrasAlfabeto :
                return i
            i=i+1

        return -1