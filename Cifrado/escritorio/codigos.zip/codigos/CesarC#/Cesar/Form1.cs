﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Cesar
{
    public partial class Form1 : Form
    {
        CifradoMensajePlano cfp = new CifradoMensajePlano();
        TransformarInverso   ti = new TransformarInverso();
        GruposInversos gi = new GruposInversos();
        public Form1()
        {
            InitializeComponent();
        }
        
        private void asignaCifrado()
        {

        }

        private void textBox1_KeyUp(object sender, KeyEventArgs e)
        {
            richTextBox1.Text = ti.inverso(textBox1.Text, "");

            richTextBox2.Text = cfp.mensajeCifrado(textBox1.Text, (int)numericUpDown1.Value, "");

            richTextBox3.Text = gi.invertir_en_grupos(textBox1.Text, (int)numericUpDown2.Value, "");
        }

        private void numericUpDown1_ValueChanged(object sender, EventArgs e)
        {
            richTextBox2.Text = cfp.mensajeCifrado(textBox1.Text, (int)numericUpDown1.Value, "");
        }

        private void numericUpDown2_ValueChanged(object sender, EventArgs e)
        {

            richTextBox3.Text = gi.invertir_en_grupos(textBox1.Text, (int)numericUpDown2.Value, "");
        }
    }
}
